﻿using System;
using System.Globalization;
using System.IO;

namespace GrapeCity.ActiveReports.Samples.Web
{
    public partial class ParameterReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PageReport report = new PageReport(new FileInfo(Server.MapPath("~") + "\\KeyIndicatorStoreReport.rdlx"));
            report.Document.Parameters["selectedReportType"].CurrentValue = ".rdlx";
            report.Document.Parameters["CurrencySymbol"].CurrentValue = "$";
            WebViewer1.Report = report;
            Session["Report"] = report;
        }
    }
}